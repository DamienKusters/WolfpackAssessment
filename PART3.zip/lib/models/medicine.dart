class MedicineModel
{
  String name;
  bool taken;

  MedicineModel(this.name, {this.taken = false});
}