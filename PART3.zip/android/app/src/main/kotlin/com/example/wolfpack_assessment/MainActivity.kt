package com.example.wolfpack_assessment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
